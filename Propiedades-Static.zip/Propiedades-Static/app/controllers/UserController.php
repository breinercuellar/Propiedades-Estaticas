<?php 
// /app/controllers/Usercontroller.php

namespace App\controllers;

use App\Models\User;

class UserController
{
    public function create($name)
    {
        // Crear un nuevo usuario
        $user = new user($name);

        // Cargar la vista y pasar el modelo user
        require_once 'app/views/welcome.php';
        // require_once__DIR__ . '/../views/user/welcome.php';
    }
}