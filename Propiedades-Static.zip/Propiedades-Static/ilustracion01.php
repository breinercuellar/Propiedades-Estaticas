<?php

class Contador

{
    public static $cuenta = 0;
    public function incrementar()
    {
         self::$cuenta++; 
         // $this->cuenta++;
    } 
}   

$contador1 = new Contador();
$contador1->incrementar();
echo Contador::$cuenta. PHP_EOL; // Imprime 1

$contador2 = new Contador();
$contador2->incrementar();

echo Contador::$cuenta. PHP_EOL; // Imprime 2