<?php

class utilidades
{
    public static function saludar($nombre)
    {
        return "Hola, " . $nombre ."!";
    }
}


echo utilidades::saludar("Mundo"); // salida: Hola, Mundo!