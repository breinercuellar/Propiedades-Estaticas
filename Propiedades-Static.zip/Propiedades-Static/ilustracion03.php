<?php
    class A 
    {
        public static function quien()
        {
            echo __CLASS__;
        }
        public static function test()
        {
            self::quien(); //Aqui self se refiere a 'A'
            static::quien(); // Aqui static se refiere a la clase que se invoca en el runtime
        }
    }

    class B extends A
    {
        public static function quien()
        {
            echo __CLASS__;
        }
    }   

    A::test(); //Salida AA
    B::test(); //Salida BB