<?php
class ClasePadre
{
    protected static $valor = 'Hola';
    public static function getvalor()
    {
        return static::$valor;  
    }
}

class ClaseHija extends ClasePadre
{
    public static function mostrarValor()
    {
        //Accede directamente a la propiedad estatica protegida
        echo static::$valor;

        // O a traves de un metodo getter si la propiedad fuera privada
        //echo static::getvalor();
    }
}

ClaseHija::mostrarValor(); // Salida: Hola