<?php
class Ejemplo 
{
    public static function MetodoEstatico()
    {
        echo"Llamada a metodo estatico.\n";
    }

    public static function otroMetodoEstatico()
    {
        //Llamada dentro de la clase utilizadando selft::
        self::metodoEstatico();

        // o usando static:: para respetar el late static Binding
        static::metodoEstatico();
    }
}

//Ejemplo::otroMetodoEstatico(); // Llamada a metodo estatico.

class EjemploHijo extends Ejemplo
{
    public static function MetodoEstatico()
    {
        echo "Llamada a metodo estatico sobrescrito en hijo.\n";
    }
}

EjemploHijo::MetodoEstatico();
// si otroMetodoEstatico() usa self:: se mostrara: Llamada a metodo estatico.
// si otroMetodoEstatico() usa static:: se mostrara: Llamada a metodo estatico sobrescrito en hijo.