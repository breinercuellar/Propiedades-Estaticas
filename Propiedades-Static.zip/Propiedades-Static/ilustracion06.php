<?php

class utilidades
{
    public static function saludar($nombre)
    {
        return "Hola, " . $nombre ."!";
    }
}

class Otraclase
{
    public function demo()
    {
        // llamada a un metodo estatico de otra clase
        echo utilidades::saludar("Pedro");
    }
}

// Crear una instancia de OtraClase y llamar a demo()
$instancia = new Otraclase();
$instancia->demo(); //salida: Hola, Pedro!