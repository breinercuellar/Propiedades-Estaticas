<?php
class ClaseA
{
    public static function metodoEstaticoA()
    {
        echo"Metodo estatico de ClaseA\n";
    }
}

class ClaseB
{
    public static function metodoEstaticoB()
    {
        // llamada a un metodo estatico de otra clase desde un metodo estatico
        ClaseA::metodoEstaticoA();
    }
}

ClaseB::metodoEstaticoB(); // salida: metodo estatico de ClaseA